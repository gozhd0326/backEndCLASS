public class Code03_11 {
	public static void main(String[] args) {
		int n1=100, n2=200;
		
		System.out.print  (n1==n2); // n1은 n2와 같음
		System.out.println(n1!=n2); // n1은 n2와 같지 않음
		
		System.out.print  (n1>n2);
		System.out.println(n1<n2);

		System.out.print  (n1>=n2);
		System.out.println(n1<=n2);
	}	
}
