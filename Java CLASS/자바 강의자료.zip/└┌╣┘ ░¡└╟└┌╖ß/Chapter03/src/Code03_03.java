public class Code03_03 {
	public static void main(String[] args) {
		int a=3, b=4, c=5;
		System.out.println(a + b - c);
		System.out.println(a - c + b);
		System.out.println(-c + a + b);
	}
}