public class Ex03_01 {
	public static void main(String[] args) {
		Turtle turtle = new Turtle();	
		
		turtle.width(10);
		turtle.penColor("red");
		
		turtle.right(45);
		
		turtle.up();
		turtle.forward(20);
		turtle.down();
		turtle.forward(20);
		
		turtle.up();
		turtle.forward(20);
		turtle.down();
		turtle.forward(20);
		
		turtle.up();
		turtle.forward(20);
		turtle.down();
		turtle.forward(20);
		
		turtle.up();
		turtle.forward(20);
		turtle.down();
		turtle.forward(20);
		
		turtle.up();
		turtle.forward(20);
		turtle.down();
		turtle.forward(20);		
	}
}
