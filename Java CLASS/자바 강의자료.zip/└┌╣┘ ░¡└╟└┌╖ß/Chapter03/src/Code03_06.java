public class Code03_06 {
	public static void main(String[] args) {
		double num;
		num = Math.pow(3, 2);
		System.out.println(num);
		num = Math.pow(4, 3);
		System.out.println(num);
	}
}