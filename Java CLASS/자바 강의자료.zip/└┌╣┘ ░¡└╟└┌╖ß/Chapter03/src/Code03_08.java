public class Code03_08 {
	public static void main(String[] args) {
		int num;
		num = 100;
		num = num + 200;
		System.out.println(num);
	}
}