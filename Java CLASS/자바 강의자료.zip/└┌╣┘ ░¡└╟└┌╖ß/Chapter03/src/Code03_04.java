public class Code03_04 {
	public static void main(String[] args) {
		double a=2, b=4, c=6;
		System.out.println(a / b * c);
		System.out.println(a * c / b);
		System.out.println(c / b * a);
	}
}