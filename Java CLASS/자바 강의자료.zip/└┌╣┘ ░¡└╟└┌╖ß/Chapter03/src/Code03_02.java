public class Code03_02 {
	public static void main(String[] args) {
		int n1, n2, res;
		n1 = 5;
		n2 = 3;
		res = n1 + n2;
		System.out.println(res);
		res = n1 - n2;
		System.out.println(res);
		res = n1 * n2;
		System.out.println(res);
		res = n1 / n2;
		System.out.println(res);
		res = n1 % n2;
		System.out.println(res);
	}
}
