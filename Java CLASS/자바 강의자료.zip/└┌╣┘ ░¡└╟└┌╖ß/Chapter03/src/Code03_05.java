public class Code03_05 {
	public static void main(String[] args) {
		int a=3, b=4, c=5;
		System.out.println(a * b + c);
		System.out.println(c + a * b);
	}
}