public class Code03_07 {
	public static void main(String[] args) {
		int num;
		num = 100;
		num = 100 * 200;
		num = Integer.parseInt("100") + Integer.parseInt("200");
	}
}