public class Code02_01 {
	public static void main(String[] args) {
		System.out.println(100+200);
	}
}