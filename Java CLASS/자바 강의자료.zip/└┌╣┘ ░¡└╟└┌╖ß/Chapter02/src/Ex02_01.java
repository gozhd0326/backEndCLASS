public class Ex02_01 {
	public static void main(String[] args) {
		Turtle turtle = new Turtle();

		// turtle.speed(500);
		turtle.forward(200);
		
		turtle.left(90); 
		turtle.forward(200);
		
		turtle.left(90); 
		turtle.forward(200);
		
		turtle.left(90); 
		turtle.forward(200);
	}
}