public class Code02_06 {
	public static void main(String[] args) {
		int num1, num2, result;
		
		num1 = 100;
		num2 = 50;			
		
		result = num1 + num2;
		System.out.println(num1 + "+" + num2 + "=" + result);
	}
}