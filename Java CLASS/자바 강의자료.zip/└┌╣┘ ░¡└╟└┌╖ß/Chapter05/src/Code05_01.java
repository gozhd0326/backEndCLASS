public class Code05_01 {
	public static void main(String[] args) {
		int num = 99;
		
		if (num < 100)
			System.out.println("100보다 작습니다.");
	}
}