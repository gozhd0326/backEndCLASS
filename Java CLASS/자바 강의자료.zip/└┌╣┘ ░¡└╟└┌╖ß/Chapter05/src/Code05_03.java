public class Code05_03 {
	public static void main(String[] args) {
		int num = 200;
		
		if (num < 100) 
			System.out.println("100보다 작군요.");
		else 
			System.out.println("100보다 크군요.");
				
	}
}