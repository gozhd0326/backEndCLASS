public class Code05_02 {
	public static void main(String[] args) {
		int num = 99;
		
		if (num < 100) {
			System.out.print("100보다 ");
			System.out.print("작습니다.");
		}
		
	}
}
