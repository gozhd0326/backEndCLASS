public class Code04_04 {
	   public static void main(String[] args) {
		      boolean boo1, boo2;

		      boo1 = true;
		      System.out.println(boo1);
		      
		      boo2 = (10 == 20);
		      System.out.println(boo2);
		   }
}