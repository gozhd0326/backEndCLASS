public class Code04_16 {
	public static void main(String[] args) {
	      String str = "Java";
	      
	      System.out.println(str.charAt(0));
	      System.out.println(str.charAt(1));
	      System.out.println(str.charAt(2));
	      System.out.println(str.charAt(3));
	      System.out.println(str.charAt(4));
	}
}
