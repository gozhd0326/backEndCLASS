public class Code04_01 {
	public static void main(String[] args) {
		byte age = 127; 
		short birth = 32767;
		int money = 2147483647; 

		System.out.println( (byte)(age + 1));
		System.out.println( (short)(birth + 1));
		System.out.println( (int)(money + 1));
	}
}
