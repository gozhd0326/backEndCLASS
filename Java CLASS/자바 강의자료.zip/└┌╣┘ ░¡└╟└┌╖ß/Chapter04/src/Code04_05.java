public class Code04_05 {
	public static void main(String[] args) {
		System.out.printf("200+300");
		System.out.println();
		System.out.printf("%d" , 200+300 );
		System.out.println();
	}
}