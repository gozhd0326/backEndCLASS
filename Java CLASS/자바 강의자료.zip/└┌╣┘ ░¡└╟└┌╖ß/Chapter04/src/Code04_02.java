public class Code04_02 {
	public static void main(String[] args) {
	      float f = 0.1234567890123456789012345f;
	      double d = 0.1234567890123456789012345;

	      System.out.println(f);
	      System.out.println(d);
	}
}
