public class Code04_10 {
	public static void main(String[] args) {
	      String str = "난생 처음 자바";
	      int len;
	
	      len = str.length();
	
	      System.out.println("문자열  : " + str);
	      System.out.println("문자열 길이 : " + len);
	}
}
