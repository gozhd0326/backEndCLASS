public class Code04_09 {
	public static void main(String[] args) {
		System.out.println("\n줄바꿈\n연습 ");
		System.out.println("\t탭키\t연습");
		System.out.println("어떤 글자를 \"강조\"하는 효과1");
		System.out.println("어떤 글자를 \'강조\'하는 효과2");
		System.out.println("\\\\ 백슬래쉬 2개 출력");
	}
}
