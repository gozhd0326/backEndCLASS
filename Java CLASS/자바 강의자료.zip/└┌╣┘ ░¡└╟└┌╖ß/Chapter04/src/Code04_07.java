public class Code04_07 {
	public static void main(String[] args) {
		String var1 = "작은 따옴표는 \' 모양입니다.";
		String var2 = "큰 따옴표는 \" 모양입니다.";
		
		System.out.println(var1);
		System.out.println(var2);
	}
}