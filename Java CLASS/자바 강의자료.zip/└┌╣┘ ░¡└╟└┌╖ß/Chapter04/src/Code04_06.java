public class Code04_06 {
	public static void main(String[] args) {
	      System.out.printf("%d / %d = %d", 100, 200, 0.5);
	}
}
