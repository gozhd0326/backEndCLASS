public class Code04_08 {
	public static void main(String[] args) {
		String var1 = "난생 처음 \n" +
				"자바를 \n" +
				"열공 중입니다.";		
		System.out.println(var1);
	}
}
