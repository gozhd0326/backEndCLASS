public class Code04_12 {
	public static void main(String[] args) {
		String ss = "First Java을 공부 중입니다.";
		String var1, var2;
		
		var1 = ss.toUpperCase();
		System.out.println(var1);
		var2 = ss.toLowerCase();
		System.out.println(var2);
	}
}
