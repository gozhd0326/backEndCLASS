public class Code04_14 {
	public static void main(String[] args) {
	      String str = "난생처음 자바";
	      
	      System.out.println(str.indexOf("난생"));
	      System.out.println(str.indexOf("처"));
	}
}
