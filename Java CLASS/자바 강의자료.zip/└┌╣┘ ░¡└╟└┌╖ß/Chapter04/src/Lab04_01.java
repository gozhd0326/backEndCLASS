public class Lab04_01 {
	public static void main(String[] args) {
		String ss = "블랙핑크";
		System.out.println("원본 문자열 ==> " + ss);

		System.out.print("반대 문자열 ==> ");
		System.out.print(ss.charAt(3));
		System.out.print(ss.charAt(2));
		System.out.print(ss.charAt(1));
		System.out.print(ss.charAt(0));
	}
}