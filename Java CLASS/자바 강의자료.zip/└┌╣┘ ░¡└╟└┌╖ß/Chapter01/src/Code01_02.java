public class Code01_02 {
	public static void main(String[] args) {
		System.out.println("저는 손흥민입니다. ^^");
	}
}