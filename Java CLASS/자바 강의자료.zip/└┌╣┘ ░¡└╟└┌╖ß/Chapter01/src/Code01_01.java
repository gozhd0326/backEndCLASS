public class Code01_01 {
	public static void main(String[] args) {
        System.out.println("안녕하세요?");
        System.out.println("이클립스에서 프로젝트를 생성했어요.");
	}
}